<?php
/**
 * 
 *
 * @package   pcfw
 * @author    Banana kreativni online marketing
 * @license   GPL-2.0+
 * @link      https://banana.com.hr/
 * @copyright Banana kreativni online marketingpcfw
 *
 * @wordpress-plugin
 * Plugin Name:       Prices converter for Woocommerce
 * Description:       Convert Woocommerce product prices
 * Version:           1.0.0.
 * Tested Up To:      6.0
 * Author:            Banana kreativni online marketing
 * Author URI:        https://banana.com.hr/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       b_pcfw
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

require_once( ABSPATH . "wp-includes/pluggable.php" );

/* CHECK - dependency - Woocommerce
---------------------------------------------------------------------------- */
register_activation_hook(__FILE__, 'pcfw_f_activation_check_dependency_woocommerce');
function pcfw_f_activation_check_dependency_woocommerce() {
    if (!class_exists( 'WooCommerce' )) {
        deactivate_plugins(plugin_basename( __FILE__ ));
        wp_die( __('Please install and activate WooCommerce.', 'pcfw' ), 'Plugin dependency check', array('back_link' => true));
    }
}
add_action('admin_init', 'pcfw_f_init_check_dependency_woocommerce');
function pcfw_f_init_check_dependency_woocommerce() {
    if (!class_exists( 'WooCommerce' )) {
        deactivate_plugins(plugin_basename( __FILE__ ));
        // wp_die( __('Please install and activate WooCommerce.', 'pcfw' ), 'Plugin dependency check', array('back_link' => true));
    }
}

/* INIT enqueue admin files
---------------------------------------------------------------------------- */
wp_enqueue_script('pcfw_jquery', plugin_dir_url( __FILE__ ) . 'core/dependencies/jquery.js', array(), '3.6.1', false);
wp_enqueue_script('pcfw', plugin_dir_url( __FILE__ ) . 'core/pcfw-admin.js', array('jquery'), '1.0.0', false);
wp_enqueue_style('pcfw', plugin_dir_url( __FILE__ ) . 'core/pcfw.css');

/* INIT localize admin files
---------------------------------------------------------------------------- */
wp_localize_script('pcfw', 'pcfw_data',
    array( 
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
    )
);

/* INIT lib vars
---------------------------------------------------------------------------- */
$pcfw_directory = plugin_dir_path(__FILE__);

/* require lib files
---------------------------------------------------------------------------- */
$pcfw_files_to_require = array(
    'core/plugin_page.php',
    'core/ajaxend/pc.php'
);
foreach ($pcfw_files_to_require as $pcfw_file_to_require) {
    require $pcfw_directory . $pcfw_file_to_require;
}