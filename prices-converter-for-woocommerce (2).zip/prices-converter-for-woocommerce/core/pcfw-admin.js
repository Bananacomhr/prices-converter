$(document).ready(function() {

    $(".pcfw_CONVERT").on("click", function() {

        var koef = $(".koef").val();

        if (confirm("Are you sure? Multiplier: "+ koef)) {
            $.ajax({
                method: "POST",
                url: pcfw_data.ajaxurl,
                dataType: 'json',
                data: { 
                    action: 'pc',
                    wpaction: 'count',
                    koef: koef
                }
            }).done(function(response) {
                if (!response.is_valid_koef) {
                    $(".pcfw_output").text('Multiplier is in non valid format! Please input multplier different from "0", "1" in format of round or decimal number using "." separator, for example: 2 or 1.5 or 0.5');
                } else {
    
                    $(".pcfw_output").text("Altering prices for total of "+ response.count +" products.");
    
                    var num_products = response.count;
                        num_products = parseInt(num_products);
    
                    var num_completed_products = response.counter_total;
    
                    // for (let i = 1; i < num_products; i + 1) {
    
                    //     var response_text = $(".pcfw_output").text();
                    //         response_text += "<br/>"+ "Altered prices for total of "+ i +" products.";
                    //         $(".pcfw_output").text(response_text);
    
                        // START visual notification
                        $.ajax({
                            method: "POST",
                            url: pcfw_data.ajaxurl,
                            dataType: 'json',
                            data: { 
                                action: 'pc',
                                wpaction: 'convert',
                                num_completed_products: num_completed_products,
                                koef: koef
                            }
                        }).done(function(response) {
                            // END visual notification
                            var response_text = $(".pcfw_output").text();
                            response_text += "<br/>"+ "Altered prices for total of "+ response.counter_total +" products.";
                            $(".pcfw_output").html(response_text);
                        });
    
                    // }
                    
                }
            });
        }

        
        
    });
    

});