<?php
if (is_admin() && !defined('DOING_AJAX')) { return; }

/* AJAXEND prices converter for Woocommerce
---------------------------------------------------------------------------- */
add_action( 'wp_ajax_pc', 'pc_cb' );
function pc_cb() {
    $koef = $_POST['koef'];
        $koef = floatval($koef);
    $is_valid_koef = ($_POST['koef'] == '' || strpos($_POST['koef'], ",") !== false || $koef == 0 || $koef == 1) ? false : true;
    $completed = $_POST['completed'];
    $counter_endpoint = (isset($completed)) ? intval($completed) + 50 : 50;
    $counter_total = (isset($completed)) ? intval($completed) : 0;
    $num_completed_products = (isset($num_completed_products)) ? intval($num_completed_products) : 0;
    $output = array();
    $counter_variable = 0;
    $counter_simple = 0;
    $counter_onsale = 0;
    $counter = 0;
    $wpaction = $_POST['wpaction'];
    global $wpdb;

    // if (strpos($_POST['koef'], ",") !== false) {
    //     echo "2";
    // }
    // return;

    if ($wpaction == 'count') {

        $number_of_products;
        if (!$is_valid_koef) {
            $number_of_products = '';
        } else {
            $number_of_products = wp_count_posts('product')->publish;
        }

        $output = array(
            'is_valid_koef' => $is_valid_koef,
            'count' => $number_of_products,
        );
        $output = (object)$output;
        $output = json_encode($output);
        echo $output;
        wp_die();

    } elseif ($wpaction == 'convert') {
        $products_query = new WP_Query(array(
            'post_type' => 'product',
            'posts_per_page' => -1,
        ));
        if ($products_query->have_posts()) {
            while ($products_query->have_posts()) {
                $products_query->the_post();
                $counter++;
        
                // if ($counter > $counter_total && $counter < $counter_endpoint) {
        
                    $post_id = get_the_ID();
                    $product = wc_get_product($post_id);
        
                    $counter_total++;
                    if ($product->is_type('variable')) { $counter_variable++; } else { $counter_simple++; }
                    if ($product->is_on_sale()) { $counter_onsale++; }
        
                    // $price = $product->get_price();
                    //     $price = floatval($price);
                    // $regular_price = $product->get_regular_price();
                    //     $regular_price = floatval($regular_price);
                    // $sale_price = $product->get_sale_price();
                    //     $sale_price = floatval($sale_price);
        
                    // $modified_price = $price * $koef;
                    // $modified_regular_price = $regular_price * $koef;
                    // $modified_sale_price = $sale_price * $koef;

                    // update_post_meta($post_id, '_price', $modified_price);
                    // update_post_meta($post_id, '_regular_price', $modified_regular_price);
                    // if (isset($sale_price) && $sale_price != 0) {
                    //     update_post_meta($post_id, '_sale_price', $modified_sale_price);
                    // }

                    array_push($test, array(
                        'id' => $post_id,
                        'object' => $product
                    ));

                // }

            }
        }
        wp_reset_postdata();

        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_regular_price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_sale_price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_regular_price_tmp' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_sale_price_tmp' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_price_tmp' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_min_variation_price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_max_variation_price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_min_variation_regular_price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_max_variation_regular_price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_min_variation_sale_price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_max_variation_sale_price' AND meta_value != ''");
        // lowest price last 30 days
        $wpdb->query("UPDATE $wpdb->price_history SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = 'price' AND meta_value != ''");
        $wpdb->query("UPDATE $wpdb->postmeta SET meta_value = ROUND(meta_value * $koef, 2)  WHERE meta_key = '_lowest_price_30_days' AND meta_value != ''");
        // delete transients
        $wpdb->query("DELETE FROM $wpdb->options WHERE (option_name LIKE '_transient_wc_var_prices_%' OR option_name LIKE '_transient_timeout_wc_var_prices_%')");


        $output = array(
            'counter_total' => $counter_total,
            'counter_variable' => $counter_variable,
            'counter_simple' => $counter_simple,
            'counter_onsale' => $counter_onsale,
            'ajax_completed' => ($counter_total == $num_completed_products) ? true : false,
        );
        $output = (object)$output;
        $output = json_encode($output);
        echo $output;
        wp_die();
    }

    /*
        wp count posts
            loop ajax until counter total equals total_products
        ajax return number of product processed
            display to user
    */



    // $products = array();

    // foreach ($products as $product) {
    //     // set_sale_price($product['price'] x $koef);
    //     update_post_meta($product['id'], '_regular_price', $product['price'] x $koef);

    //     // set_price($product['price'] x $koef);
    //     update_post_meta($product['id'], '_sale_price', $product['price'] x $koef);
    // }
}