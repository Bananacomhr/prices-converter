<?php


/** -------------------------------------------------------------------------------------------------------------------
 * INIT -> pcfw settings
*/
function pcfw_submenu_prices_converter() {
    add_menu_page(
        'Prices converter for Woocommerce products',
        'PCfWoo',
        'manage_options',
        'pcfw',
        'pcfw_submenu_prices_converter_html',
        'dashicons-bank'
    );
    // add_submenu_page(
    //     'pcfw',
    //     'Prices converter for Woocommerce products',
    //     'Prices converter',
    //     'manage_options',
    //     'pcfw_submenu_prices_converter',
    //     'pcfw_submenu_prices_converter_html'
    // );
}
add_action('admin_menu', 'pcfw_submenu_prices_converter');
function pcfw_submenu_prices_converter_html() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    ?>
    <div class="wrap">
        <h1>Prices converter for Woocommerce products</h1>
        <br>Input multiplier <input class="pcfw_input koef" placeholder="1.5"/>
        <div class="pcfw_button pcfw_CONVERT">CONVERT</div>
        <div class="pcfw_output"></div>
        <?php
            // $num = 10;
            // $num *= 0.5;
            // echo '<pre>'; var_dump($num); echo '</pre>';
        ?>
    </div>
    <?php
}