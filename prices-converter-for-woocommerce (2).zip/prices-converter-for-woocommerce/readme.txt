=== Prices converter for Woocommerce ===
Requires at least: 5.9.2
Tested up to: 6.0
Requires PHP: 7.0
License: GPL-2.0+
License URI: http://www.gnu.org/licenses/gpl-2.0.txt

Convert Woocommerce product prices.